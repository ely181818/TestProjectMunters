
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;

namespace TestProject1
{
    class Tests
    {
        
        String test_url = "https://duckduckgo.com/";

        IWebDriver driver;

        [SetUp]
        public void start_Browser()
        {
            // Local Selenium WebDriver
            driver = new ChromeDriver();
            driver.Manage().Window.Maximize();
        }

        [Test]
        public void case_1()
        {
            driver.Url = test_url;
            WaitUntilElementClickable(driver, By.XPath("//*[@id='search_form_input_homepage']"));

            IWebElement searchText = driver.FindElement(By.XPath("//*[@id='search_form_input_homepage']"));

            searchText.SendKeys("wthermelons");

            IWebElement searchButton = driver.FindElement(By.XPath("//*[@id='search_button_homepage']"));
            WaitUntilElementClickable(driver, By.XPath("//*[@class='acp']"));
          
            IList<IWebElement> displayedOptions = driver.FindElements(By.XPath("//*[@class='acp']"));
            int  test = displayedOptions.Count(se => se.Displayed);
            Assert.IsTrue(test == 8, "The actualCount was Not equal to eight");

            Console.WriteLine("Test Passed");
        }

        [Test]
        public void case_2()
        {
            driver.Url = test_url;

            WaitUntilElementClickable(driver, By.XPath("//*[@id='search_form_input_homepage']"));

            IWebElement searchText = driver.FindElement(By.XPath("//*[@id='search_form_input_homepage']"));

            searchText.SendKeys("wthermelons");

            IWebElement searchButton = driver.FindElement(By.XPath("//*[@id='search_button_homepage']"));


            searchButton.Click();


           
            WaitUntilElementClickable(driver, By.CssSelector("div[class='result results_links_deep highlight_d result--url-above-snippet']"));

            IList<IWebElement> results_right = driver.FindElements(By.CssSelector("div[class='result results_links_deep highlight_d result--url-above-snippet']"));
            int results_right_count = results_right.Count(se => se.Displayed);
            Console.WriteLine("results_count" + results_right_count);
            Assert.IsTrue(results_right_count == 10, "The actualCount was Not equal to ten");

            IList<IWebElement> results_left = driver.FindElements(By.CssSelector("div[class='module__content js-about-module-content']"));
            int results_left_count = results_left.Count(se => se.Displayed);
            Console.WriteLine("results_left_count" + results_left_count);
            Assert.IsTrue(results_left_count == 1, "The actualCount was Not equal to ten one");
            Console.WriteLine("Test Passed");


        }

        [Test]
        public void case_3()
        {
            driver.Url = test_url;

            WaitUntilElementClickable(driver, By.XPath("//*[@id='search_form_input_homepage']"));

            IWebElement searchText = driver.FindElement(By.XPath("//*[@id='search_form_input_homepage']"));
            searchText.SendKeys("wthermelons");
            IWebElement searchButton = driver.FindElement(By.XPath("//*[@id='search_button_homepage']"));
            searchButton.Click();
           
            WaitUntilElementClickable(driver, By.CssSelector("div[class='result results_links_deep highlight_d result--url-above-snippet']"));
            IList <IWebElement> results_right = driver.FindElements(By.CssSelector("div[class='result results_links_deep highlight_d result--url-above-snippet']"));
            int results_right_count = results_right.Count(se => se.Displayed);
            Console.WriteLine("results_right_count" + results_right_count);
            Assert.IsTrue(results_right_count == 10, "The actualCount was Not equal to ten");

            List<string> first_list_results = new List<string>();
            first_list_results = Return_list(results_right);

            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            ((IJavaScriptExecutor)driver).ExecuteScript("window.scrollTo(0, document.body.scrollHeight - 150)");
            driver.FindElement(By.CssSelector("div[class='result result--more']")).Click();



            IList<IWebElement> results_right_2 = driver.FindElements(By.CssSelector("div[class='result results_links_deep highlight_d result--url-above-snippet']"));
            int results_right_count_2 = results_right_2.Count(se => se.Displayed);
            Console.WriteLine("results_count" + results_right_count);
            Assert.IsTrue(results_right_count_2 > 20, "The actualCount was not greater than 20");

            List<string> second_list_results = new List<string>();

            second_list_results = Return_list(results_right_2);


            bool flag = (second_list_results.Any(x => first_list_results.Any(y => y == x)));
            if (flag)
            {
                Console.WriteLine("The ten results of the first search results exist in the new list of extended search ");
            }
            else
            {
                Assert.IsTrue(flag, "No Match Found!");
                Console.WriteLine("No Match Found!");
            }


            Console.WriteLine("Test Passed");


        }

        public static List<string> Return_list(IList<IWebElement> data)
        {

            List<string> second_list_results = new List<string>();
            for (int i = 0; i < data.Count; i++)
            {
                IWebElement searchTextBox = data.ElementAt(i);
                String typeValue = searchTextBox.GetAttribute("data-domain");
                second_list_results.Add(typeValue);
            }

            return second_list_results;

        }

        public static IWebElement WaitUntilElementClickable(IWebDriver driver,By elementLocator, int timeout = 10)
        {
            try
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeout));
                return wait.Until(ExpectedConditions.ElementToBeClickable(elementLocator));
            }
            catch (NoSuchElementException)
            {
                Console.WriteLine("Element with locator: '" + elementLocator + "' was not found in current context page.");
                throw;
            }
        }

        [TearDown]
        public void close_Browser()
        {
            driver.Quit();
        }
    }
}